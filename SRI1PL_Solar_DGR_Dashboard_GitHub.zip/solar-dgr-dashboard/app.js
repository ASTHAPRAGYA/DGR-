let rows = [];
let filtered = [];
const charts = {};

const FIELD = {
  date: "Date",
  pa: "PA(%)",
  pr: "PR(%)",
  ghi: "GHI-UP (KWh/m2)",
  poaUp: "POA-UP(KWh/m2)",
  poaDown: "POA-Down(KWh/m2)",
  measured: "Inv_Exp (kWh)",
  actual: "220kV_Net_Exp (KWh)",
  capacity: "Firm DC Capacity (MWp)"
};

const $ = id => document.getElementById(id);

function pct(v){ return Number.isFinite(v) ? (v * 100).toFixed(2) + "%" : "—"; }
function num(v){ return Number.isFinite(v) ? v.toLocaleString(undefined,{maximumFractionDigits:2}) : "—"; }
function toDate(v){
  if(v instanceof Date) return v;
  if(typeof v === "number"){
    const d = XLSX.SSF.parse_date_code(v);
    return new Date(d.y,d.m-1,d.d);
  }
  const d = new Date(v);
  return isNaN(d) ? null : d;
}
function iso(d){ return d.toISOString().slice(0,10); }
function label(d){ return d.toLocaleDateString("en-IN",{day:"2-digit",month:"short"}); }

function cleanNumber(v){
  if(v === null || v === undefined || v === "") return NaN;
  if(typeof v === "number") return v;
  const n = parseFloat(String(v).replace(/,/g,"").replace("%",""));
  return Number.isFinite(n) ? n : NaN;
}

function normalise(raw){
  return raw.map(r => {
    const d = toDate(r[FIELD.date]);
    if(!d) return null;
    const capacity = cleanNumber(r[FIELD.capacity]);
    return {
      date:d,
      pa:cleanNumber(r[FIELD.pa]),
      pr:cleanNumber(r[FIELD.pr]),
      ghi:cleanNumber(r[FIELD.ghi]),
      poaUp:cleanNumber(r[FIELD.poaUp]),
      poaDown:cleanNumber(r[FIELD.poaDown]),
      measured:cleanNumber(r[FIELD.measured]),
      actual:cleanNumber(r[FIELD.actual]),
      capacity:capacity
    };
  }).filter(Boolean).sort((a,b)=>a.date-b.date);
}

function chartBase(id,type,title,labels,datasets,options={}){
  if(charts[id]) charts[id].destroy();
  charts[id] = new Chart($(id),{
    type,
    data:{labels,datasets},
    options:{
      responsive:true, maintainAspectRatio:false,
      interaction:{mode:"index",intersect:false},
      plugins:{legend:{display:true,position:"top"},tooltip:{callbacks:{label:c=>{
        const v=c.parsed.y;
        return `${c.dataset.label}: ${Number.isFinite(v)?v.toLocaleString(undefined,{maximumFractionDigits:2}):"—"}`;
      }}}},
      scales:{x:{grid:{display:false}},y:{beginAtZero:false}},
      ...options
    }
  });
}

function lineDataset(label,data){
  return {label,data,borderWidth:2,pointRadius:2,tension:.28,fill:false};
}

function render(){
  filtered = getFilteredRows();
  if(!filtered.length) return;

  const labels = filtered.map(r=>label(r.date));
  chartBase("paChart","line","Plant Availability",labels,[lineDataset("PA (%)",filtered.map(r=>r.pa*100))],{scales:{y:{min:Math.max(0,Math.floor(Math.min(...filtered.map(r=>r.pa*100))-1)),max:100}}});
  chartBase("prChart","line","Performance Ratio",labels,[lineDataset("PR (%)",filtered.map(r=>r.pr*100))],{scales:{y:{beginAtZero:false}}});
  chartBase("ghiChart","line","GHI",labels,[lineDataset("GHI (kWh/m²)",filtered.map(r=>r.ghi))]);
  chartBase("giiChart","line","GII / POA",labels,[
    lineDataset("POA Up (kWh/m²)",filtered.map(r=>r.poaUp)),
    lineDataset("POA Down (kWh/m²)",filtered.map(r=>r.poaDown))
  ]);
  chartBase("generationChart","line","Generation",labels,[
    lineDataset("Measured / Inverter Export (kWh)",filtered.map(r=>r.measured)),
    lineDataset("Actual / 220 kV Net Export (kWh)",filtered.map(r=>r.actual))
  ]);

  // AEY is cumulative net generation divided by the plant DC capacity.
  // Since the report's capacity is in MWp and generation is kWh:
  // AEY (kWh/kWp) = cumulative kWh / (MWp * 1000 kWp/MWp)
  const fyStart = new Date(filtered[0].date.getFullYear(),3,1);
  let cumulative = 0;
  const aey = filtered.map(r=>{
    cumulative += Number.isFinite(r.actual) ? r.actual : 0;
    const cap = r.capacity || filtered[0].capacity;
    return cap ? cumulative/(cap*1000) : NaN;
  });
  chartBase("aeyChart","line","Annual Energy Yield",labels,[lineDataset("Cumulative AEY (kWh/kWp)",aey)]);

  const latest = filtered[filtered.length-1];
  $("kpiPA").textContent = pct(latest.pa);
  $("kpiPR").textContent = pct(latest.pr);
  $("kpiGen").textContent = num(latest.actual/1000) + " MWh";
  $("kpiGenDetail").textContent = `220 kV net export • ${iso(latest.date)}`;
  const latestAEY = aey[aey.length-1];
  $("kpiAEY").textContent = num(latestAEY);
  $("dataStatus").textContent = `${rows.length} DGR days loaded • Showing ${filtered.length} days • Latest: ${iso(latest.date)}`;
}

function getFilteredRows(){
  if(!rows.length) return [];
  const from = $("fromDate").value ? new Date($("fromDate").value+"T00:00:00") : null;
  const to = $("toDate").value ? new Date($("toDate").value+"T23:59:59") : null;
  if(from || to) return rows.filter(r=>(!from || r.date>=from)&&(!to || r.date<=to));
  const selected = document.querySelector(".range-buttons button.selected")?.dataset.range || "30";
  if(selected==="all") return rows;
  return rows.slice(-Number(selected));
}

function setRange(n){
  document.querySelectorAll(".range-buttons button").forEach(b=>b.classList.toggle("selected",b.dataset.range===String(n)));
  $("fromDate").value=""; $("toDate").value="";
  if(rows.length) render();
}

function findHeader(sheet){
  const matrix = XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:null});
  for(let i=0;i<Math.min(matrix.length,15);i++){
    const line = (matrix[i]||[]).map(x=>String(x??"").trim());
    if(line.includes("Date") && line.includes("PA(%)") && line.includes("PR(%)")) return i;
  }
  return -1;
}

function parseWorkbook(wb){
  // The supplied SRI1PL DGR stores the daily series in Daily_KPI.
  // The fallback scans all sheets for a header containing Date + PA + PR.
  let sheet = wb.Sheets["Daily_KPI"];
  let headerRow = sheet ? 3 : -1;
  if(!sheet || headerRow<0){
    for(const name of wb.SheetNames){
      const s=wb.Sheets[name], h=findHeader(s);
      if(h>=0){sheet=s;headerRow=h;break;}
    }
  }
  if(!sheet) throw new Error("Could not find a Daily_KPI-style sheet containing Date, PA(%) and PR(%).");

  const matrix = XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:null});
  const headers = matrix[headerRow].map(x=>String(x??"").trim());
  const data=[];
  for(let i=headerRow+1;i<matrix.length;i++){
    const arr=matrix[i];
    if(!arr || !arr.length) continue;
    const obj={};
    headers.forEach((h,j)=>{if(h)obj[h]=arr[j];});
    data.push(obj);
  }
  return {data,headers,sheetName:wb.SheetNames.find(n=>wb.Sheets[n]===sheet)||"Daily_KPI"};
}

async function handleFile(file){
  if(!file) return;
  try{
    const buffer=await file.arrayBuffer();
    const wb=XLSX.read(buffer,{type:"array",cellDates:true});
    const parsed=parseWorkbook(wb);
    rows=normalise(parsed.data);
    if(!rows.length) throw new Error("The detected sheet contains no usable daily records.");

    const cap=rows.find(r=>Number.isFinite(r.capacity))?.capacity;
    if(cap) $("plantCapacity").textContent=`${cap.toFixed(2)} MWp DC / 191.7 MW AC`;

    $("mappingInfo").innerHTML =
      `<strong>Detected sheet:</strong> ${parsed.sheetName}<br>
       <strong>Date:</strong> ${FIELD.date} · <strong>PA:</strong> ${FIELD.pa} · <strong>PR:</strong> ${FIELD.pr}<br>
       <strong>GHI:</strong> ${FIELD.ghi} · <strong>GII/POA:</strong> ${FIELD.poaUp} / ${FIELD.poaDown}<br>
       <strong>Measured generation:</strong> ${FIELD.measured} · <strong>Actual generation:</strong> ${FIELD.actual}`;
    $("fromDate").min=iso(rows[0].date); $("fromDate").max=iso(rows.at(-1).date);
    $("toDate").min=iso(rows[0].date); $("toDate").max=iso(rows.at(-1).date);
    render();
    document.querySelector(".upload-panel").scrollIntoView({behavior:"smooth",block:"center"});
  }catch(err){
    console.error(err);
    alert("DGR upload failed: "+err.message);
  }
}

document.querySelectorAll(".range-buttons button").forEach(b=>b.addEventListener("click",()=>setRange(b.dataset.range)));
$("applyDate").addEventListener("click",()=>{document.querySelectorAll(".range-buttons button").forEach(b=>b.classList.remove("selected"));render()});
$("resetDate").addEventListener("click",()=>setRange(30));
$("dgrInput").addEventListener("change",e=>handleFile(e.target.files[0]));

const dz=$("dropzone");
dz.addEventListener("click",()=>$("dgrInput").click());
["dragenter","dragover"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.style.background="#e9f7f8"}));
["dragleave","drop"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.style.background=""}));
dz.addEventListener("drop",e=>handleFile(e.dataTransfer.files[0]));
