# SRI1PL Solar DGR Dashboard

Interactive solar plant performance dashboard built around the supplied `DGR_SRI1PL.xlsx`.

## What it reads

The supplied DGR contains a `Daily_KPI` sheet. The dashboard maps:

- **Plant Availability:** `PA(%)`
- **Performance Ratio:** `PR(%)`
- **GHI:** `GHI-UP (KWh/m2)`
- **GII / POA:** `POA-UP(KWh/m2)` and `POA-Down(KWh/m2)`
- **Measured generation:** `Inv_Exp (kWh)`
- **Actual generation:** `220kV_Net_Exp (KWh)`
- **DC capacity:** `Firm DC Capacity (MWp)`

The workbook's percentage values are stored as decimals (for example, `0.999869` = `99.9869%`), so the dashboard converts PA and PR to percentage display.

## AEY calculation

The dashboard plots cumulative annual energy yield as:

`AEY (kWh/kWp) = cumulative 220 kV net generation (kWh) / DC capacity (kWp)`

For example, a 252.3378 MWp plant has 252,337.8 kWp of DC capacity.

## Run locally

Because this is a static site, no backend is required.

1. Download/clone the repository.
2. Open `index.html` in a browser.
3. Click **Upload DGR** and select the Excel report.

For GitHub Pages, push the files to a repository and enable **Settings → Pages → Deploy from branch**.

## Important

The DGR is processed entirely in the browser using SheetJS. No Excel file is uploaded to a server by this project.

The parser first looks for the supplied `Daily_KPI` sheet and falls back to scanning sheets for a row containing `Date`, `PA(%)`, and `PR(%)`.
